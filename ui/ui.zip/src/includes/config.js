// config.js

// const apiPath = 'http://localhost:8000/index.php';
// const preURLValue = '/';

// const apiPath = 'https://liveconf-dev.quiklrn.net/liveconf/api/index.php';
// const preURLValue = '/liveconf/ui/';

const apiPath = 'https://meetings.quiklrn.com/api/index.php';
const preURLValue = '/ui/';

export { apiPath, preURLValue };